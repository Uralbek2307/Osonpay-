# OsonPay — Flutter MVP

OsonPay fintech ilovasining demo/MVP starter loyihasi.

## Ishga tushirish
1. Flutter SDK o‘rnating.
2. `flutter pub get`
3. `flutter run`

Bu versiya demo: real bank/to‘lov operatsiyalari bajarilmaydi.

## Keyingi production bosqichlari
- Backend/API
- SMS OTP va autentifikatsiya
- PIN/biometrik himoya
- Uzcard/Humo/payment provider integratsiyasi
- Push notifications
- PostgreSQL va audit loglari
- KYC/AML va zarur litsenziya/huquqiy talablar
