import 'package:flutter/material.dart';

const green = Color(0xFF22C55E);
const blue = Color(0xFF3882F6);
const bg = Color(0xFF06121F);
const panel = Color(0xFF0D1B2A);

void main() => runApp(const OsonPayApp());

class OsonPayApp extends StatelessWidget {
  const OsonPayApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'OsonPay',
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.dark)),
    home: const LoginPage(),
  );
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final phone = TextEditingController();
  @override Widget build(BuildContext context)=>Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
    const Spacer(),
    Center(child: Container(width:82,height:82,decoration:BoxDecoration(color:green,borderRadius:BorderRadius.circular(26)),child:const Icon(Icons.account_balance_wallet_rounded,size:45,color:Colors.white))),
    const SizedBox(height:20), const Center(child: Text('OsonPay',style:TextStyle(fontSize:34,fontWeight:FontWeight.w900))),
    const SizedBox(height:8), const Center(child:Text('To‘lovlar — oson, hayot — yengil.',style:TextStyle(color:Colors.white60))),
    const SizedBox(height:42), const Text('Telefon raqamingiz',style:TextStyle(fontWeight:FontWeight.w700)), const SizedBox(height:8),
    TextField(controller:phone,keyboardType:TextInputType.phone,decoration:InputDecoration(hintText:'+998 90 123 45 67',filled:true,fillColor:panel,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none))),
    const SizedBox(height:14), SizedBox(width:double.infinity,height:56,child:FilledButton(onPressed:()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const MainShell())),style:FilledButton.styleFrom(backgroundColor:green),child:const Text('Kirish',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)))),
    const SizedBox(height:12), const Center(child:Text('Demo versiya • real to‘lov amalga oshirilmaydi',style:TextStyle(color:Colors.white38,fontSize:12))),
    const Spacer(),
  ]))));
}

class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState()=>_MainShellState(); }
class _MainShellState extends State<MainShell> {
  int index=0;
  final pages=const [HomePage(),TransactionsPage(),ServicesPage(),ProfilePage()];
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:pages[index]),bottomNavigationBar:NavigationBar(
    selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),backgroundColor:const Color(0xFF071827),indicatorColor:green.withOpacity(.18),
    destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Bosh sahifa'),NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'Tarix'),NavigationDestination(icon:Icon(Icons.grid_view_rounded),selectedIcon:Icon(Icons.grid_view_rounded),label:'Xizmatlar'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profil')],
  ));
}

class HomePage extends StatelessWidget { const HomePage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.fromLTRB(18,10,18,24),children:[
    Row(children:[const CircleAvatar(radius:21,child:Icon(Icons.person)),const SizedBox(width:12),const Expanded(child:Text('Assalomu alaykum!\nOsonPay',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800))),IconButton(onPressed:()=>showDialog(context:context,builder:(_)=>const AlertDialog(title:Text('Bildirishnomalar'),content:Text('Hozircha yangi bildirishnoma yo‘q.'))),icon:const Icon(Icons.notifications_none_rounded))]),
    const SizedBox(height:18), Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF0B3150),Color(0xFF0E6B54)])),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Umumiy balans',style:TextStyle(color:Colors.white70)),const SizedBox(height:7),const Text('12 450 000 UZS',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),const SizedBox(height:16),Row(children:[const Expanded(child:Text('OsonPay Card  •••• 4587',style:TextStyle(fontWeight:FontWeight.w700))),IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CardsPage())),icon:const Icon(Icons.chevron_right))])])),
    const SizedBox(height:18), Row(children:[ActionButton(Icons.send_rounded,'O‘tkazish',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TransferPage()))),ActionButton(Icons.credit_card_rounded,'Kartalar',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CardsPage()))),ActionButton(Icons.qr_code_2_rounded,'QR to‘lov',()=>showDialog(context:context,builder:(_)=>const AlertDialog(title:Text('QR to‘lov'),content:Icon(Icons.qr_code_2_rounded,size:150)))),ActionButton(Icons.add_card_rounded,'To‘ldirish',()=>showDialog(context:context,builder:(_)=>const AlertDialog(title:Text('Balansni to‘ldirish'),content:Text('Demo: karta tanlash oynasi keyingi versiyada.'))))]),
    const SizedBox(height:22),const Text('Tezkor xizmatlar',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:10),Wrap(spacing:10,runSpacing:10,children:const [ServiceChip(Icons.receipt,'Kommunal'),ServiceChip(Icons.wifi,'Internet'),ServiceChip(Icons.phone_android,'Mobil aloqa'),ServiceChip(Icons.tv,'TV')]),
    const SizedBox(height:22),InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FlightPage())),borderRadius:BorderRadius.circular(20),child:Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xFF10283C),borderRadius:BorderRadius.circular(20)),child:const Row(children:[Icon(Icons.flight_takeoff_rounded,size:42,color:blue),SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Aviachipta',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),SizedBox(height:4),Text('Oson va qulay parvoz qidiring',style:TextStyle(color:Colors.white60))])),Icon(Icons.arrow_forward_ios_rounded,size:16)]))),
    const SizedBox(height:22),const Text('So‘nggi amallar',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const TransactionTile(Icons.shopping_bag_outlined,'Uzum Market','Bugun, 08:21','-135 000 UZS',false),const TransactionTile(Icons.home_work_outlined,'Ipoteka to‘lovi','Bugun, 07:45','-2 500 000 UZS',false),const TransactionTile(Icons.arrow_downward_rounded,'Pul kelib tushdi','Kecha, 21:30','+3 000 000 UZS',true),
  ]);
}

class ActionButton extends StatelessWidget { final IconData icon; final String text; final VoidCallback onTap; const ActionButton(this.icon,this.text,this.onTap,{super.key}); @override Widget build(BuildContext c)=>Expanded(child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(16),child:Column(children:[Container(width:54,height:54,decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(17)),child:Icon(icon,color:green)),const SizedBox(height:7),Text(text,textAlign:TextAlign.center,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w600))]))); }
class ServiceChip extends StatelessWidget { final IconData icon; final String text; const ServiceChip(this.icon,this.text,{super.key}); @override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:12),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),child:Row(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:19,color:green),const SizedBox(width:8),Text(text)])); }
class TransactionTile extends StatelessWidget { final IconData icon; final String title,subtitle,amount; final bool income; const TransactionTile(this.icon,this.title,this.subtitle,this.amount,this.income,{super.key}); @override Widget build(BuildContext c)=>ListTile(contentPadding:EdgeInsets.zero,leading:CircleAvatar(backgroundColor:panel,child:Icon(icon,color:income?green:blue)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(subtitle,style:const TextStyle(color:Colors.white54)),trailing:Text(amount,style:TextStyle(color:income?green:Colors.redAccent,fontWeight:FontWeight.w800))); }

class TransactionsPage extends StatelessWidget { const TransactionsPage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[const Text('Tranzaksiyalar',style:TextStyle(fontSize:27,fontWeight:FontWeight.w900)),const SizedBox(height:18),const TransactionTile(Icons.shopping_bag_outlined,'Uzum Market','Bugun, 08:21','-135 000 UZS',false),const TransactionTile(Icons.home_work_outlined,'Ipoteka to‘lovi','Bugun, 07:45','-2 500 000 UZS',false),const TransactionTile(Icons.arrow_downward,'Pul kelib tushdi','Kecha, 21:30','+3 000 000 UZS',true),const TransactionTile(Icons.phone_android,'Mobil aloqa','Kecha, 18:12','-45 000 UZS',false),const TransactionTile(Icons.swap_horiz,'O‘tkazma','Kecha, 16:05','-200 000 UZS',false)]); }

class ServicesPage extends StatelessWidget { const ServicesPage({super.key}); @override Widget build(BuildContext c)=>GridView.count(padding:const EdgeInsets.all(18),crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,children:[ServiceCard(Icons.receipt_long,'To‘lovlar',()=>showDemo(c,'To‘lovlar')),ServiceCard(Icons.credit_card,'Kartalar',()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const CardsPage()))),ServiceCard(Icons.flight,'Aviachipta',()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const FlightPage()))),ServiceCard(Icons.account_balance_wallet,'TezHamyon',()=>showDemo(c,'TezHamyon')),ServiceCard(Icons.qr_code_2,'QR to‘lov',()=>showDemo(c,'QR to‘lov')),ServiceCard(Icons.support_agent,'Yordam',()=>showDemo(c,'Qo‘llab-quvvatlash'))]); }
}
class ServiceCard extends StatelessWidget { final IconData icon; final String text; final VoidCallback tap; const ServiceCard(this.icon,this.text,this.tap,{super.key}); @override Widget build(BuildContext c)=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(22),child:Container(decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(22)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,size:38,color:green),const SizedBox(height:10),Text(text,style:const TextStyle(fontWeight:FontWeight.w800))]))); }
void showDemo(BuildContext c,String title)=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$title: demo funksiyasi.')));

class ProfilePage extends StatelessWidget { const ProfilePage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[const Text('Profil',style:TextStyle(fontSize:27,fontWeight:FontWeight.w900)),const SizedBox(height:20),const Center(child:CircleAvatar(radius:42,child:Icon(Icons.person,size:40))),const SizedBox(height:12),const Center(child:Text('OsonPay foydalanuvchisi',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))),const SizedBox(height:24),...['Shaxsiy ma’lumotlar','Xavfsizlik va PIN','Biometrik kirish','Bildirishnomalar','Til: O‘zbekcha','Qo‘llab-quvvatlash'].map((x)=>Card(color:panel,child:ListTile(title:Text(x),trailing:const Icon(Icons.chevron_right))))]); }

class TransferPage extends StatefulWidget { const TransferPage({super.key}); @override State<TransferPage> createState()=>_TransferPageState(); }
class _TransferPageState extends State<TransferPage> { final to=TextEditingController(); final amount=TextEditingController(); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Pul o‘tkazish')),body:Padding(padding:const EdgeInsets.all(18),child:Column(children:[TextField(controller:to,decoration:field('Karta yoki telefon raqami')),const SizedBox(height:14),TextField(controller:amount,keyboardType:TextInputType.number,decoration:field('Summa (UZS)')),const SizedBox(height:14),TextField(decoration:field('Izoh (ixtiyoriy)')),const Spacer(),SizedBox(width:double.infinity,height:54,child:FilledButton(onPressed:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('Tasdiqlash'),content:Text('${amount.text.isEmpty?'0':amount.text} UZS yuborilsinmi?'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Bekor qilish')),FilledButton(onPressed:(){Navigator.pop(c);ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Demo: o‘tkazma bajarildi.')));},child:const Text('Tasdiqlash'))])),style:FilledButton.styleFrom(backgroundColor:green),child:const Text('O‘tkazish',style:TextStyle(fontWeight:FontWeight.w800))))]))); }
InputDecoration field(String s)=>InputDecoration(labelText:s,filled:true,fillColor:panel,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none)); }

class CardsPage extends StatelessWidget { const CardsPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Kartalar')),body:ListView(padding:const EdgeInsets.all(18),children:[Container(height:190,padding:const EdgeInsets.all(22),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF172A46),Color(0xFF0E6B54)])),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('OsonPay Card',style:TextStyle(fontSize:21,fontWeight:FontWeight.w800)),Spacer(),Text('•••• 4587',style:TextStyle(fontSize:23,letterSpacing:2)),SizedBox(height:8),Text('VISA',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))])),const SizedBox(height:18),ListTile(tileColor:panel,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),leading:const Icon(Icons.credit_card,color:green),title:const Text('HUMO •••• 2366'),trailing:const Icon(Icons.chevron_right)),const SizedBox(height:10),ListTile(tileColor:panel,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),leading:const Icon(Icons.credit_card,color:blue),title:const Text('UZCARD •••• 9812'),trailing:const Icon(Icons.chevron_right)),const SizedBox(height:18),SizedBox(height:52,child:FilledButton.icon(onPressed:()=>showDemo(c,'Karta qo‘shish'),icon:const Icon(Icons.add),label:const Text('Karta qo‘shish')))])); }

class FlightPage extends StatelessWidget { const FlightPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Aviachipta')),body:ListView(padding:const EdgeInsets.all(18),children:[flightField('Qayerdan','Toshkent (TAS)'),flightField('Qayerga','Istanbul (IST)'),flightField('Jo‘nash sanasi','15-sentabr, 2026'),const SizedBox(height:18),SizedBox(height:54,child:FilledButton(onPressed:()=>showDemo(c,'Aviachipta qidiruvi'),style:FilledButton.styleFrom(backgroundColor:green),child:const Text('Qidirish'))),const SizedBox(height:24),const Text('Mashhur yo‘nalishlar',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const ListTile(leading:Icon(Icons.flight,color:green),title:Text('Toshkent → Istanbul'),subtitle:Text('Bir tomonga • Ekonom'))])); }
static Widget flightField(String a,String b)=>Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Colors.white54)),const SizedBox(height:5),Text(b,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w700))])); }
